#include <Arduino.h>

#define MQ2_PIN 34
#define BUZZER_PIN 25
#define LED_PIN 2

#define GAS_THRESHOLD 1800

void setup() {
  Serial.begin(115200);

  pinMode(LED_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);

  digitalWrite(LED_PIN, LOW);
  noTone(BUZZER_PIN);

  Serial.println("Gas Leakage Alert System Started");
}

void loop() {
  int gasValue = analogRead(MQ2_PIN);

  Serial.print("Gas Sensor Reading: ");
  Serial.println(gasValue);

  if (gasValue >= GAS_THRESHOLD) {
    digitalWrite(LED_PIN, HIGH);
    tone(BUZZER_PIN, 2000);

    Serial.println("WARNING: GAS LEAKAGE DETECTED!");
  } else {
    digitalWrite(LED_PIN, LOW);
    noTone(BUZZER_PIN);

    Serial.println("Status: Normal");
  }

  delay(500);
}